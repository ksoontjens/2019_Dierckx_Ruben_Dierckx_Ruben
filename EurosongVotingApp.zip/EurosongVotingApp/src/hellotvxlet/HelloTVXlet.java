package hellotvxlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Timer;
import javax.tv.xlet.*;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HStaticText;
import org.havi.ui.HTextButton;
import org.havi.ui.HVisible;     
import org.havi.ui.event.HActionListener;

public class HelloTVXlet implements Xlet, UserEventListener , HActionListener{
    HScene scene;
    String[] land={"Australia","Ukraine","France","Malta","Russia","Belgium","Bulgaria","Israel","Sweden","Armenia","The Netherlands","Lithuania","Italy","Georgia","Latvia","Spain","United Kingdom","Hungary","Azebaijan","Cyprus","Czech Republic","Croatia","Serbia","Austria","Poland","Germany"};
    HTextButton[] button=new HTextButton[26];
    HStaticText[] punten=new HStaticText[26];
    int[] scores=new int[26];
    int givenScore = 12;
    MijnComponent mc = new MijnComponent(0, 0, 720, 576);

    public HelloTVXlet() {
    }

    public void initXlet(XletContext context) {
        scene = HSceneFactory.getInstance().getDefaultHScene();
        Font f=new Font("Tiresias",Font.PLAIN,21);
        
        for (int i=0;i<26;i++)
        {
            if (i<13)
            {
                button[i]=new HTextButton(land[i],25,50+i*40,250,35);
                punten[i]=new HStaticText("0",275,50+i*40,50,35);
       
            }
            else
            {
                button[i]=new HTextButton(land[i],375,50+(i-13)*40,250,35);
                punten[i]=new HStaticText("0",625,50+(i-13)*40,50,35);
            }
            button[i].setFont(f);
            punten[i].setFont(f);
            button[i].setBackground(Color.BLUE);
            button[i].setBackgroundMode(HVisible.BACKGROUND_FILL);   
            
            punten[i].setBackground(Color.BLUE);
            punten[i].setBackgroundMode(HVisible.BACKGROUND_FILL);
            button[i].setActionCommand(land[i]);
            button[i].addHActionListener(this);
            
            scene.add(button[i]);  
            scene.add(punten[i]);
        }
 
         for (int i=0;i<26;i++)
         {
             HTextButton boven=null;
             HTextButton onder=null;
             HTextButton links=null;
             HTextButton rechts=null;
             if (i!=0 && i!=13) boven= button[i-1];
             if (i!=12 && i!=25) onder= button[i+1];
             if (i>13) links= button[i-13];
             if (i<13) rechts= button[i+13]; 
             
       //      System.out.println(links);
              button[i].setFocusTraversal(boven, onder, links, rechts);
         }
 
        UserEventRepository rep = new UserEventRepository("naam");
        rep.addAllArrowKeys();
        EventManager manager = EventManager.getInstance();
        manager.addUserEventListener(this, rep);

        scene.add(mc);
        scene.validate();
        scene.setVisible(true);
        button[0].requestFocus();
          
        Timer t = new Timer();
        MijnTimerTask mtt = new MijnTimerTask();
	
        mtt.setMc(mc);
    
        t.scheduleAtFixedRate(mtt, 0, 50);
    }

    public void userEventReceived(UserEvent e) {
    }

    public void startXlet() {
    }

    public void pauseXlet() {
    }

    public void destroyXlet(boolean unconditional) {
    }

    public void actionPerformed(ActionEvent arg0) {
     System.out.println(arg0.getActionCommand());

     for (int i=0;i<26;i++)
     {
      if (arg0.getActionCommand().equals(land[i]) && givenScore>0)
      {
          if (scores[i]!=0) return;
               
     if(givenScore==11)
     {
         givenScore--;
     }
     if(givenScore==9)
     {
         givenScore--;
     }
          scores[i]=+ givenScore;
          punten[i].setTextContent(String.valueOf(scores[i]), HVisible.NORMAL_STATE);
          givenScore--;
      }
     }
    }
}
package hellotvxlet;

import java.util.TimerTask;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author student
 */
public class MijnTimerTask extends TimerTask {

// maken een nieuw component aan
    MijnComponent mc;

//stellen nieuwe mc gelijk aan de meegegeven huidige waarde van het component mc_p
    public void setMc(MijnComponent mc_p) {
        mc = mc_p;
    }
	
	
	
    public void run() {
	//punt printen om timing te testen    
		System.out.println(".");
	//mc.ay=mc.ay+10
	//we tellen elke keer de timertask in hellotvxlet uitgevoerd wordt 10 op bij de y coordinaat van onze sterrenkaart
	//waardoor deze lijkt te bewegen
	
	// mtt.setMc(mc);
    // t.scheduleAtFixedRate(mtt, 0, 50);
	// daar dus ^
        mc.ay += 5;
        //repaint want da moet zie oef 1
		mc.repaint();

		// als 1 van de 2 sterrenkaarten volledig verschoven is van y coordinaat 0 naar 570 (want onze scene is 576 groot dus beetje marge)
		// stellen we de y terug gelijk aan 0 zodat deze opnieuw verschoven kan worden
        if (mc.ay > 570) {
            mc.ay = 0;
        }
    }
}
